from mai_validation import main

if __name__ == "__main__":
    raise SystemExit(main("mission"))
